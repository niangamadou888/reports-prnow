import fs from 'fs';
import path from 'path';

export interface PDFRecord {
  slug: string;
  originalName: string;
  uploadedAt: string;
  fileSize: number;
}

const DATA_FILE = path.join(process.cwd(), 'uploads', 'data.json');
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');

// Ensure uploads directory exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

function loadData(): PDFRecord[] {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('Error loading data:', error);
  }
  return [];
}

function saveData(records: PDFRecord[]): void {
  fs.writeFileSync(DATA_FILE, JSON.stringify(records, null, 2));
}

// Generate a random slug (6 characters, alphanumeric)
export function generateSlug(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let slug = '';
  for (let i = 0; i < 6; i++) {
    slug += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return slug;
}

// Generate unique slug (check for duplicates)
export function generateUniqueSlug(): string {
  const records = loadData();
  const existingSlugs = new Set(records.map(r => r.slug));

  let slug = generateSlug();
  let attempts = 0;

  while (existingSlugs.has(slug) && attempts < 100) {
    slug = generateSlug();
    attempts++;
  }

  if (attempts >= 100) {
    // Fallback to longer slug
    slug = generateSlug() + generateSlug();
  }

  return slug;
}

export function addPDF(record: PDFRecord): void {
  const records = loadData();
  records.push(record);
  saveData(records);
}

export function getAllPDFs(): PDFRecord[] {
  return loadData().sort((a, b) =>
    new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
  );
}

export function getPDF(slug: string): PDFRecord | undefined {
  const records = loadData();
  return records.find(r => r.slug === slug);
}

export function deletePDF(slug: string): boolean {
  const records = loadData();
  const index = records.findIndex(r => r.slug === slug);

  if (index === -1) return false;

  // Delete the file
  const filePath = path.join(UPLOADS_DIR, `${slug}.pdf`);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }

  // Remove from records
  records.splice(index, 1);
  saveData(records);

  return true;
}

export function getFilePath(slug: string): string {
  return path.join(UPLOADS_DIR, `${slug}.pdf`);
}
