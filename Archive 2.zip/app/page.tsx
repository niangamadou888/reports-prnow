import { redirect } from 'next/navigation';

export default function Home() {
  redirect('https://prnow.io');
}
